export default {
  logoUrl: "https://dummyimage.com/64x64/0346AC/FCF8EB.png&text=R"
};
