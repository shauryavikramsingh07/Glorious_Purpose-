import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';

type View = 'Overview' | 'Simulation' | 'Findings' | 'History' | 'Trust';
type AuditState = 'ready' | 'running' | 'complete';
type SimulationState = 'idle' | 'running' | 'complete';

const personas = [
  { id: 'first', name: 'First-time user', meta: 'Zero prior context', icon: 'user', color: 'blue' },
  { id: 'impatient', name: 'Impatient user', meta: 'Low patience threshold', icon: 'bolt', color: 'orange' },
  { id: 'screen', name: 'Screen-reader user', meta: 'Accessibility tree only', icon: 'accessibility', color: 'purple' },
  { id: 'mobile', name: 'Slow-mobile user', meta: '3G · small viewport', icon: 'phone', color: 'green' },
];

const findings = [
  { id: 1, severity: 'Critical', title: 'Primary CTA is visually buried below the fold', detail: '3 of 4 personas hesitated before starting the flow.', selector: '#hero .cta-group', category: 'Clarity', confidence: 94, affected: ['First-time', 'Impatient', 'Slow-mobile'], evidence: 'Screenshot · step 04', tone: 'critical' },
  { id: 2, severity: 'Major', title: 'Email field has no visible label', detail: 'Screen-reader user could not identify the required input.', selector: 'input[name="email"]', category: 'Accessibility', confidence: 99, affected: ['Screen-reader'], evidence: 'Verified check · axe-core', tone: 'major' },
  { id: 3, severity: 'Major', title: 'Pricing copy makes the next step ambiguous', detail: 'Two agents re-read the pricing section before continuing.', selector: '.pricing-card .fine-print', category: 'Usability', confidence: 87, affected: ['First-time', 'Impatient'], evidence: 'Replay · steps 11–14', tone: 'major' },
  { id: 4, severity: 'Minor', title: 'Mobile overflow clips the testimonial quote', detail: 'No task impact, but it adds visual noise at 390px.', selector: '.testimonial-card', category: 'Performance', confidence: 91, affected: ['Slow-mobile'], evidence: 'Viewport capture · 390px', tone: 'minor' },
];

const runs = [
  { date: 'Today, 10:42 AM', url: 'staging.rehearsalai.dev', result: '3 findings', duration: '2m 18s', state: 'Needs review' },
  { date: 'Yesterday, 4:18 PM', url: 'staging.rehearsalai.dev', result: '7 findings', duration: '3m 04s', state: 'Needs review' },
  { date: 'Nov 20, 9:07 AM', url: 'localhost:3000', result: '0 findings', duration: '1m 42s', state: 'Clear' },
];

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const, 'aria-hidden': true };
  const paths: Record<string, React.ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    play: <><path d="m8 5 11 7-11 7V5Z"/></>,
    search: <><circle cx="10.8" cy="10.8" r="6.8"/><path d="m16 16 5 5"/></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/></>,
    shield: <><path d="M12 3 20 6v5c0 5-3.3 8.2-8 10-4.7-1.8-8-5-8-10V6l8-3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></>,
    settings: <><path d="M12 15.2a3.2 3.2 0 1 0 0-6.4 3.2 3.2 0 0 0 0 6.4Z"/><path d="m19.4 15 .1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.8 1.8 0 0 0-3.1 1.3v.2a2 2 0 1 1-4 0v-.2A1.8 1.8 0 0 0 6.4 18l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.8 1.8 0 0 0 2.3 12a1.8 1.8 0 0 0 1.3-3.1l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.8 1.8 0 0 0 9.5 4.8v-.2a2 2 0 1 1 4 0v.2A1.8 1.8 0 0 0 16.6 6l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.8 1.8 0 0 0 20.7 12a1.8 1.8 0 0 0-1.3 3Z"/></>,
    help: <><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.3 2.3 0 1 1 3.7 1.8c-1 .7-1.5 1.1-1.5 2.5"/><path d="M12 17h.01"/></>,
    external: <><path d="M14 4h6v6"/><path d="m20 4-9 9"/><path d="M19 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/></>,
    arrow: <><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    sparkle: <><path d="m12 3 1.3 4.7L18 9l-4.7 1.3L12 15l-1.3-4.7L6 9l4.7-1.3L12 3Z"/><path d="m19 15 .6 2.4L22 18l-2.4.6L19 21l-.6-2.4L16 18l2.4-.6L19 15Z"/></>,
    user: <><circle cx="12" cy="8" r="3.5"/><path d="M5 20a7 7 0 0 1 14 0"/></>,
    bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z"/>,
    accessibility: <><circle cx="12" cy="4" r="1.5"/><path d="M5 8h14M12 7v13M8 20l4-7 4 7"/></>,
    phone: <><rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M10 5h4M11.5 18.5h1"/></>,
    refresh: <><path d="M20 11a8 8 0 0 0-14.8-4L3 10"/><path d="M3 5v5h5"/><path d="M4 13a8 8 0 0 0 14.8 4L21 14"/><path d="M21 19v-5h-5"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    eye: <><path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></>,
    pulse: <path d="M3 12h4l2-7 4 14 2-7h6"/>,
  };
  return <svg {...common}>{paths[name] || paths.grid}</svg>;
}

function BrandMark() {
  return <div className="brand-mark" aria-hidden="true"><span>R</span><span className="brand-spark">✦</span></div>;
}

function App() {
  const [activeView, setActiveView] = useState<View>('Overview');
  const [url, setUrl] = useState('https://staging.rehearsalai.dev');
  const [auditState, setAuditState] = useState<AuditState>('ready');
  const [selectedFinding, setSelectedFinding] = useState(findings[0]);
  const [selectedPersonas, setSelectedPersonas] = useState(['first', 'impatient', 'screen']);
  const [simulationState, setSimulationState] = useState<SimulationState>('idle');
  const [progress, setProgress] = useState(0);
  const [toast, setToast] = useState('');

  useEffect(() => {
    if (simulationState !== 'running') return;
    const timer = window.setInterval(() => {
      setProgress((current) => {
        const next = Math.min(current + 8, 100);
        if (next === 100) setSimulationState('complete');
        return next;
      });
    }, 420);
    return () => window.clearInterval(timer);
  }, [simulationState]);

  const runAudit = () => {
    if (auditState === 'running') return;
    setAuditState('running');
    setToast('Local checks running in your browser…');
    window.setTimeout(() => {
      setAuditState('complete');
      setToast('Quick Audit complete · 18 checks verified');
    }, 1700);
  };

  const runSimulation = () => {
    setActiveView('Simulation');
    setSimulationState('running');
    setProgress(8);
    setToast('Simulation started · agents are entering isolated browsers');
  };

  const togglePersona = (id: string) => {
    setSelectedPersonas((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  };

  const auditLabel = auditState === 'ready' ? 'Run Quick Audit' : auditState === 'running' ? 'Auditing current screen…' : 'Audit complete';
  const auditIcon = auditState === 'complete' ? 'check' : auditState === 'running' ? 'pulse' : 'sparkle';

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand-lockup"><BrandMark /><div><strong>Rehearsal<span>AI</span></strong><small>Persona rehearsal engine</small></div></div>
        <div className="workspace-switcher"><div className="workspace-avatar">A</div><div><small>Workspace</small><strong>Acme Labs</strong></div><Icon name="chevron" size={15} /></div>
        <nav className="side-nav" aria-label="Primary navigation">
          <div className="nav-group-label">Workspace</div>
          {(['Overview', 'Simulation', 'Findings', 'History'] as View[]).map((item) => <button key={item} className={`nav-item ${activeView === item ? 'active' : ''}`} onClick={() => setActiveView(item)}><Icon name={item === 'Overview' ? 'grid' : item === 'Simulation' ? 'play' : item === 'Findings' ? 'search' : 'history'} size={17} /><span>{item}</span>{item === 'Findings' && <em>4</em>}</button>)}
          <div className="nav-group-label nav-group-label-spaced">Account</div>
          <button className={`nav-item ${activeView === 'Trust' ? 'active' : ''}`} onClick={() => setActiveView('Trust')}><Icon name="shield" size={17} /><span>Trust & privacy</span></button>
          <button className="nav-item" onClick={() => setToast('Settings are coming with Builder Growth.') }><Icon name="settings" size={17} /><span>Settings</span></button>
        </nav>
        <div className="sidebar-bottom">
          <div className="credit-card"><div className="credit-top"><span>RUN CREDITS</span><span className="tiny-pill">PRO</span></div><strong>28 <small>/ 50</small></strong><div className="credit-bar"><span /></div><button onClick={() => setToast('Plan management is ready for the next step.')}><span>Manage plan</span><Icon name="arrow" size={14} /></button></div>
          <div className="user-row"><div className="user-avatar">AS</div><div><strong>Arjun S.</strong><small>Builder account</small></div><button aria-label="Open account menu" onClick={() => setToast('Account menu opened.')}><Icon name="chevron" size={15} /></button></div>
        </div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" aria-label="Open navigation"><Icon name="menu" size={20} /></button><div className="breadcrumbs"><span>Acme Labs</span><b>/</b><strong>{activeView}</strong></div><div className="top-actions"><div className="live-chip"><span className="live-dot" /> All systems operational</div><button className="icon-button" aria-label="Help" onClick={() => setToast('Help center is coming soon.')}><Icon name="help" size={18} /></button><div className="mini-avatar">AS</div></div></header>

        {activeView === 'Overview' && <Overview url={url} setUrl={setUrl} auditState={auditState} auditLabel={auditLabel} auditIcon={auditIcon} runAudit={runAudit} selectedFinding={selectedFinding} setSelectedFinding={setSelectedFinding} selectedPersonas={selectedPersonas} togglePersona={togglePersona} runSimulation={runSimulation} setActiveView={setActiveView} />}
        {activeView === 'Simulation' && <SimulationWorkspace selectedPersonas={selectedPersonas} togglePersona={togglePersona} simulationState={simulationState} progress={progress} runSimulation={runSimulation} setActiveView={setActiveView} />}
        {activeView === 'Findings' && <FindingsWorkspace selectedFinding={selectedFinding} setSelectedFinding={setSelectedFinding} setActiveView={setActiveView} />}
        {activeView === 'History' && <HistoryWorkspace setToast={setToast} />}
        {activeView === 'Trust' && <TrustWorkspace />}
      </main>
      {toast && <button className="toast" onClick={() => setToast('')}><span className="toast-icon"><Icon name="check" size={15} /></span>{toast}<span className="toast-close">×</span></button>}
    </div>
  );
}

function PageIntro({ eyebrow, title, copy, action }: { eyebrow: string; title: React.ReactNode; copy: string; action?: React.ReactNode }) {
  return <div className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" />{eyebrow}</div><h1>{title}</h1><p>{copy}</p></div>{action}</div>;
}

function Overview({ url, setUrl, auditState, auditLabel, auditIcon, runAudit, selectedFinding, setSelectedFinding, selectedPersonas, togglePersona, runSimulation, setActiveView }: any) {
  return <>
    <PageIntro eyebrow="The builder cockpit" title={<>Rehearse before <em>real life.</em></>} copy="Find the friction before your users do. Run a fast audit, then put real browser agents through the flow." action={<div className="ai-simulated-stamp"><span className="stamp-dot" /> AI-SIMULATED WORKSPACE <Icon name="shield" size={14} /></div>} />
    <section className="hero-grid">
      <div className="audit-card card-dark">
        <div className="card-kicker"><span className="number-badge">01</span><span>Quick Audit</span><span className="kicker-rule" /><span className="local-badge"><Icon name="lock" size={12} /> Local-first</span></div>
        <div className="audit-copy"><h2>See what your screen is saying.</h2><p>Run deterministic checks in-browser, then send only a redacted preview for AI visual review.</p></div>
        <div className="url-row"><div className="url-input-wrap"><Icon name="external" size={16} /><input aria-label="Preview URL" value={url} onChange={(e) => setUrl(e.target.value)} /></div><button className={`primary-button audit-button ${auditState}`} onClick={runAudit} disabled={auditState === 'running'}><Icon name={auditIcon} size={16} />{auditLabel}</button></div>
        <div className="audit-foot"><span><span className={`status-dot ${auditState === 'complete' ? 'success' : ''}`} />{auditState === 'complete' ? 'Last run just now' : 'Ready for a 30-second insight'}</span><span className="muted-separator">·</span><span>18 local checks included</span></div>
      </div>
      <div className="insight-card card-cream"><div className="insight-top"><div className="insight-icon"><Icon name="pulse" size={20} /></div><span className="verified-chip"><Icon name="check" size={12} /> VERIFIED CHECKS</span></div><div className="insight-metric"><strong>{auditState === 'complete' ? '18' : '—'}</strong><span>checks<br />verified</span></div><div className="insight-bottom"><span>Time to first insight</span><strong>{auditState === 'complete' ? '18 sec' : '< 30 sec'}</strong></div></div>
    </section>

    <section className="section-block"><div className="section-heading"><div><span className="section-label">02 / SIMULATION</span><h2>Put the flow through its paces.</h2></div><button className="text-button" onClick={() => setActiveView('Simulation')}>Open simulation workspace <Icon name="arrow" size={15} /></button></div>
      <div className="simulation-card"><div className="simulation-left"><div className="goal-label">Goal <span>Plain language works best</span></div><h3>Sign up and reach the dashboard</h3><div className="template-row"><span className="template-chip selected">Onboarding</span><span className="template-chip">Login</span><span className="template-chip">Checkout</span><span className="template-chip">Pricing</span><button className="more-chip">+ 3 more</button></div><div className="sim-meta"><div><span>Step budget</span><strong>25 actions</strong></div><div><span>Est. runtime</span><strong>3–5 min</strong></div><div><span>Agents selected</span><strong>{selectedPersonas.length} personas</strong></div></div></div><div className="simulation-right"><div className="agent-stack">{selectedPersonas.slice(0, 3).map((id: string, index: number) => { const p = personas.find((item) => item.id === id)!; return <div className={`agent-avatar agent-${p.color}`} key={id} style={{ zIndex: 5 - index }}><Icon name={p.icon} size={17} /></div>; })}{selectedPersonas.length > 3 && <div className="agent-avatar agent-more">+{selectedPersonas.length - 3}</div>}</div><div><strong>Ready when you are.</strong><span>Stateful agents, isolated browsers.</span></div><button className="primary-button dark-button" onClick={runSimulation}><Icon name="play" size={15} /> Run simulation</button></div></div>
    </section>

    <section className="dashboard-grid"><div className="findings-card surface-card"><div className="section-heading compact"><div><span className="section-label">03 / FRICTION REPORT</span><h2>What needs your attention</h2></div><button className="round-link" aria-label="View all findings" onClick={() => setActiveView('Findings')}><Icon name="arrow" size={15} /></button></div><div className="findings-list">{findings.slice(0, 3).map((finding) => <button className={`finding-row ${selectedFinding.id === finding.id ? 'selected' : ''}`} key={finding.id} onClick={() => setSelectedFinding(finding)}><div className={`severity-rail ${finding.tone}`} /><div className="finding-index">0{finding.id}</div><div className="finding-main"><strong>{finding.title}</strong><span>{finding.category} · {finding.affected.length} persona{finding.affected.length > 1 ? 's' : ''} affected</span></div><div className="confidence"><span>Confidence</span><strong>{finding.confidence}%</strong></div><Icon name="chevron" size={16} /></button>)}</div><button className="full-report-link" onClick={() => setActiveView('Findings')}>Open full friction report <Icon name="arrow" size={15} /></button></div><ReadinessCard /></section>

    <section className="lower-grid"><div className="history-card surface-card"><div className="section-heading compact"><div><span className="section-label">04 / RUN HISTORY</span><h2>Keep the loop tight.</h2></div><button className="text-button" onClick={() => setActiveView('History')}>View all <Icon name="arrow" size={15} /></button></div><div className="history-mini-list">{runs.slice(0, 2).map((run) => <div className="history-mini-row" key={run.date}><div className="history-icon"><Icon name="history" size={16} /></div><div><strong>{run.date}</strong><span>{run.url} · {run.duration}</span></div><div className="run-result"><strong>{run.result}</strong><span className={run.state === 'Clear' ? 'clear-state' : ''}>{run.state}</span></div><Icon name="chevron" size={15} /></div>)}</div></div><div className="trust-card"><div className="trust-card-head"><div className="trust-icon"><Icon name="shield" size={19} /></div><span>TRUST LAYER</span></div><h3>Your data stays yours.</h3><p>Redacted client-side. Encrypted in transit and at rest. Never used for model training.</p><div className="trust-points"><span><Icon name="check" size={13} /> User-triggered only</span><span><Icon name="check" size={13} /> Delete on command</span></div><button className="cream-button" onClick={() => setActiveView('Trust')}>Read our privacy promise <Icon name="arrow" size={14} /></button></div></section>
  </>;
}

function ReadinessCard() {
  const items = [{ label: 'Usability', score: 78, color: 'blue' }, { label: 'Accessibility', score: 92, color: 'green' }, { label: 'Clarity', score: 64, color: 'orange' }, { label: 'Performance', score: 87, color: 'purple' }];
  return <div className="readiness-card surface-card"><div className="readiness-head"><div><span className="section-label">READINESS</span><h2>How ready is this flow?</h2></div><span className="sim-label">AI-Simulated</span></div><div className="readiness-score"><strong>80</strong><span>/ 100<br />overall</span></div><div className="readiness-list">{items.map((item) => <div className="readiness-row" key={item.label}><span>{item.label}</span><div className="readiness-track"><i className={item.color} style={{ width: `${item.score}%` }} /></div><strong>{item.score}</strong></div>)}</div><div className="readiness-note"><span className="status-dot success" />Based on 1 run · compare after you ship a fix</div></div>;
}

function SimulationWorkspace({ selectedPersonas, togglePersona, simulationState, progress, runSimulation, setActiveView }: any) {
  const agentProgress = useMemo(() => personas.map((persona, index) => ({ ...persona, progress: Math.min(100, Math.max(0, progress - index * 11)), state: progress > 72 - index * 8 ? 'Completed' : progress > 0 ? 'In progress' : 'Ready' })), [progress]);
  return <><PageIntro eyebrow="Simulation workspace" title={<>Make the agents <em>earn</em> the answer.</>} copy="Select a diverse crew, set a goal, and watch stateful browser sessions reveal where the flow breaks." action={<span className="ai-simulated-stamp"><span className="stamp-dot" /> AI-SIMULATED <Icon name="shield" size={14} /></span>} /><div className="workspace-layout"><div className="workspace-main"><div className="workspace-panel surface-card"><div className="panel-heading"><div><span className="section-label">01 / SET A GOAL</span><h2>What should they try?</h2></div><span className="step-count">1 of 3</span></div><div className="goal-input"><Icon name="sparkle" size={17} /><input defaultValue="Sign up and reach the dashboard" aria-label="Simulation goal" /></div><div className="template-row"><span className="template-chip selected">Onboarding</span><span className="template-chip">Login</span><span className="template-chip">Support</span><span className="template-chip">Pricing</span></div></div><div className="workspace-panel surface-card"><div className="panel-heading"><div><span className="section-label">02 / CHOOSE PERSONAS</span><h2>Who should try it?</h2></div><span className="step-count">{selectedPersonas.length} selected</span></div><div className="persona-grid">{personas.map((persona) => <button key={persona.id} className={`persona-option ${selectedPersonas.includes(persona.id) ? 'selected' : ''}`} onClick={() => togglePersona(persona.id)}><div className={`persona-icon persona-${persona.color}`}><Icon name={persona.icon} size={18} /></div><div><strong>{persona.name}</strong><span>{persona.meta}</span></div><span className="check-box">{selectedPersonas.includes(persona.id) && <Icon name="check" size={13} />}</span></button>)}</div></div><div className="workspace-panel run-panel surface-card"><div><span className="section-label">03 / RUN BUDGET</span><h2>25 actions · hard cap</h2><p>Agents retry one failed action with variation. Infra failures never deduct credits.</p></div><button className="primary-button" onClick={runSimulation} disabled={simulationState === 'running'}><Icon name={simulationState === 'running' ? 'pulse' : 'play'} size={16} />{simulationState === 'running' ? 'Simulation running…' : 'Start simulation'}</button></div></div><aside className="workspace-aside"><div className="live-run-card card-dark"><div className="live-run-top"><span className="section-label light">LIVE RUN</span><span className={`run-state ${simulationState}`}>{simulationState === 'idle' ? 'Ready' : simulationState === 'running' ? 'Running' : 'Complete'}</span></div><div className="run-progress-ring" style={{ '--progress': progress } as React.CSSProperties}><div><strong>{progress}%</strong><span>complete</span></div></div><h3>{simulationState === 'idle' ? 'Your agents are ready.' : simulationState === 'running' ? 'Agents are exploring…' : 'Run complete.'}</h3><p>{simulationState === 'idle' ? 'Start a run to stream their actions here.' : simulationState === 'running' ? 'Patience meters and confusion counters update live.' : 'Open the friction report to review the evidence.'}</p>{simulationState === 'complete' && <button className="cream-button" onClick={() => setActiveView('Findings')}>Open friction report <Icon name="arrow" size={14} /></button>}</div><div className="agent-status-panel surface-card"><div className="section-heading compact"><div><span className="section-label">AGENTS</span><h2>Parallel sessions</h2></div><span className="live-dot" /></div>{agentProgress.map((agent) => <div className="agent-status-row" key={agent.id}><div className={`agent-avatar small agent-${agent.color}`}><Icon name={agent.icon} size={14} /></div><div className="agent-status-copy"><strong>{agent.name}</strong><span>{agent.state === 'Completed' ? 'Goal reached' : agent.state === 'In progress' ? (agent.id === 'screen' ? 'Navigating via a11y tree' : 'Clicking through onboarding') : 'Waiting to start'}</span></div><div className="agent-mini-progress"><i style={{ width: `${agent.progress}%` }} /></div><span className="agent-percent">{agent.progress}%</span></div>)}</div></aside></div></>;
}

function FindingsWorkspace({ selectedFinding, setSelectedFinding, setActiveView }: any) {
  return <><PageIntro eyebrow="Evidence-backed friction report" title={<>Every finding comes with <em>receipts.</em></>} copy="Prioritized by severity × personas affected. Nothing here is a synthetic quote or a black-box score." action={<span className="ai-simulated-stamp"><span className="stamp-dot" /> AI-SIMULATED REPORT <Icon name="shield" size={14} /></span>} /><div className="report-layout"><div className="report-list surface-card"><div className="report-list-head"><div><span className="section-label">4 FINDINGS</span><h2>Prioritized friction</h2></div><button className="filter-button">All severities <Icon name="chevron" size={14} /></button></div>{findings.map((finding) => <button className={`report-finding ${selectedFinding.id === finding.id ? 'selected' : ''}`} key={finding.id} onClick={() => setSelectedFinding(finding)}><div className={`severity-badge ${finding.tone}`}>{finding.severity}</div><strong>{finding.title}</strong><p>{finding.detail}</p><div className="report-finding-meta"><span>{finding.category}</span><span>·</span><span>{finding.affected.length} persona{finding.affected.length > 1 ? 's' : ''}</span><span>·</span><span>{finding.confidence}% confidence</span></div><Icon name="chevron" size={16} /></button>)}</div><div className="finding-detail"><div className="detail-header"><span className={`severity-badge ${selectedFinding.tone}`}>{selectedFinding.severity}</span><span className="detail-id">Finding 0{selectedFinding.id}</span></div><h2>{selectedFinding.title}</h2><p className="detail-lead">{selectedFinding.detail}</p><div className="evidence-frame"><div className="browser-chrome"><span /><span /><span /><small>{selectedFinding.selector}</small></div><div className="evidence-canvas"><div className="evidence-glow" /><div className="evidence-line line-one" /><div className="evidence-line line-two" /><div className="evidence-cta">Continue</div><div className="evidence-callout"><b>01</b><span>Element flagged<br /><strong>{selectedFinding.selector}</strong></span></div></div><div className="evidence-caption"><Icon name="eye" size={14} /> Evidence capture · {selectedFinding.evidence}</div></div><div className="detail-meta-grid"><div><span>Confidence level</span><strong>{selectedFinding.confidence}%</strong></div><div><span>Personas affected</span><strong>{selectedFinding.affected.length} of 4</strong></div><div><span>Category</span><strong>{selectedFinding.category}</strong></div></div><div className="suggested-fix"><div className="fix-icon"><Icon name="sparkle" size={16} /></div><div><span>SUGGESTED FIX</span><p>{selectedFinding.id === 1 ? 'Move the primary CTA into the first viewport and give it one clear action label.' : selectedFinding.id === 2 ? 'Add a persistent visible label and connect it to the input with aria-labelledby.' : 'Rewrite the supporting copy to answer the next decision in one sentence.'}</p></div></div><button className="text-button replay-button" onClick={() => setActiveView('Simulation')}><Icon name="play" size={14} /> Replay stuck point</button></div></div></>;
}

function HistoryWorkspace({ setToast }: { setToast: (s: string) => void }) {
  return <><PageIntro eyebrow="Run history" title={<>Keep the loop <em>tight.</em></>} copy="Compare rehearsals over time and make sure fixes stay fixed." action={<button className="primary-button" onClick={() => setToast('New run ready from the Simulation workspace.')}><Icon name="play" size={15} /> New simulation</button>} /><div className="history-summary-row"><div className="summary-stat surface-card"><span>Total rehearsals</span><strong>12</strong><small>+3 this month</small></div><div className="summary-stat surface-card"><span>Issues resolved</span><strong>24</strong><small className="positive">↑ 18% from last month</small></div><div className="summary-stat surface-card"><span>Latest readiness</span><strong>80<span>/100</span></strong><small>+12 since first run</small></div></div><div className="full-history-card surface-card"><div className="section-heading compact"><div><span className="section-label">VERSION TIMELINE</span><h2>Recent rehearsals</h2></div><button className="filter-button">This month <Icon name="chevron" size={14} /></button></div>{runs.map((run, index) => <div className="full-history-row" key={run.date}><div className="timeline-mark"><span /><i /></div><div className="full-history-date"><strong>{run.date}</strong><span>{index === 0 ? 'Current version · v0.8.2' : index === 1 ? 'v0.8.1' : 'v0.8.0'}</span></div><div className="full-history-url"><strong>{run.url}</strong><span>{run.duration} · {index === 0 ? '3 personas' : '4 personas'}</span></div><div className="full-history-result"><strong>{run.result}</strong><span className={run.state === 'Clear' ? 'clear-state' : ''}>{run.state}</span></div><button className="round-link" onClick={() => setToast(`Comparison loaded for ${run.date}.`)}><Icon name="arrow" size={15} /></button></div>)}</div></>;
}

function TrustWorkspace() {
  const trustItems = [{ title: 'Local-first redaction', copy: 'Input fields, passwords, email, phone and card patterns are masked in the browser before anything leaves your device.', icon: 'lock' }, { title: 'User-triggered only', copy: 'No background recording. Audits and simulations start only when you press the button.', icon: 'pulse' }, { title: 'Encrypted, not E2EE', copy: 'Cloud analysis is encrypted in transit and at rest. We never claim end-to-end encryption when a model needs to see evidence.', icon: 'shield' }, { title: 'No model training', copy: 'Your screenshots, DOM and reports are never used to train foundation models and are deleted on your command.', icon: 'check' }];
  return <><PageIntro eyebrow="Trust & privacy" title={<>Radical honesty is a <em>feature.</em></>} copy="RehearsalAI helps you see blind spots without pretending a simulation is a human study or a guaranteed prediction." action={<div className="ai-simulated-stamp"><span className="stamp-dot" /> PRIVACY PROMISE <Icon name="shield" size={14} /></div>} /><div className="trust-hero card-dark"><div><span className="section-label light">THE TRUST LAYER</span><h2>Evidence over confidence.</h2><p>Every report carries an AI-Simulated badge. Deterministic checks say “Verified Check.” AI findings show a confidence level, evidence link, and the exact surface that was inspected.</p></div><div className="trust-seal"><Icon name="shield" size={34} /><span>AI-Simulated<br /><strong>always labeled</strong></span></div></div><div className="trust-grid">{trustItems.map((item) => <div className="trust-detail surface-card" key={item.title}><div className="trust-detail-icon"><Icon name={item.icon} size={18} /></div><h3>{item.title}</h3><p>{item.copy}</p></div>)}</div><div className="deletion-panel surface-card"><div><span className="section-label">YOUR CONTROL</span><h2>Delete any run with one click.</h2><p>Reports and screenshots auto-delete after 30 days. Instant deletion is always available from the run menu.</p></div><button className="secondary-button">View data controls <Icon name="arrow" size={15} /></button></div></>;
}

createRoot(document.getElementById('root')!).render(<App />);
