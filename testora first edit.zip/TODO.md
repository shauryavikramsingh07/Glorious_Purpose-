# RehearsalAI cockpit

## Responsive product shell
- [x] Provide a responsive, accessible product shell with navigation, status badges, clear empty/loading states, and builder-oriented calls to action.
- [x] Use the supplied palette: `#0346AC`, `#FFFFFF`, `#DCE4F2`, `#FCF8EB`, and black text on light surfaces.

## Quick Audit workspace
- [x] Provide a prominent URL entry point, audit status, time-to-first-insight messaging, and verified local checks.
- [x] Show local-first redaction, user-triggered-only analysis, and AI-simulation trust language.

## Simulation workspace
- [x] Let builders choose a goal template and multiple personas, review step budgets, and start a simulation run.
- [x] Show parallel persona agents with current actions, patience/confusion signals, and completion states.

## Findings and history
- [x] Provide prioritized friction findings with severity, affected personas, confidence, suggested fixes, evidence references, and replay context.
- [x] Show readiness across Usability, Accessibility, Clarity, and Performance with explicit AI-Simulated labeling.
- [x] Include run history and a regression-oriented comparison surface.

## Verification
- [ ] Run production build and resolve actionable diagnostics.
- [ ] Configure the managed dev command and verify the preview responds.
